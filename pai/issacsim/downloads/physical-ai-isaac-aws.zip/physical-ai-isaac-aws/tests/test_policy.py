"""Offline tests only. Synthetic observations below are NOT simulator evidence."""

import contextlib
import io
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace

import numpy as np

CODE = Path(__file__).resolve().parents[1] / "static" / "code"
sys.path.insert(0, str(CODE))
sys.path.insert(0, str(CODE / "device"))

from workshop_core import (
    MAX_ANGULAR,
    MAX_LINEAR,
    MAX_RANGE,
    NUM_SECTORS,
    SCAN_TIMEOUT,
    STOP_DISTANCE,
    Policy,
    SafetyGuard,
    expert_action,
    normalize_observations,
    safe_action,
    scan_to_sectors,
)
from train import episode_split, load_dataset, train_policy
from ros_policy_node import COMMAND_TYPE, DEFAULT_MAX_LINEAR, EdgeController, build_parser


def test_only_scan(angle_min=-math.pi, *, front_distance=None):
    """360 synthetic rays for unit tests; no claim about a real LaserScan."""
    increment = math.tau / 360
    angles = angle_min + np.arange(360) * increment
    samples = np.full(360, 2.0)
    if front_distance is not None:
        offset = np.remainder(angles + math.pi, math.tau) - math.pi
        samples[np.abs(offset) < math.radians(5)] = front_distance
    return SimpleNamespace(
        ranges=samples,
        angle_min=angle_min,
        angle_increment=increment,
        range_min=0.05,
        range_max=3.5,
    )


def sectors_for(scan):
    return scan_to_sectors(
        scan.ranges, scan.angle_min, scan.angle_increment, scan.range_min, scan.range_max
    )


def test_only_policy(seed=12, hidden=8):
    rng = np.random.default_rng(seed)
    return Policy(
        rng.normal(0, 0.2, (NUM_SECTORS, hidden)),
        np.zeros(hidden),
        rng.normal(0, 0.2, (hidden, 2)),
        np.zeros(2),
    )


def test_only_dataset():
    """A smooth learnable mapping to test backprop, not workshop training data."""
    rng = np.random.default_rng(41)
    observations = rng.uniform(0.3, MAX_RANGE, size=(480, NUM_SECTORS))
    x = observations / MAX_RANGE
    actions = np.column_stack(
        (
            (np.tanh(2 * x[:, 0] + x[:, 11] - 1.5) + 1) * MAX_LINEAR / 2,
            np.tanh(1.8 * (x[:, 2] - x[:, 9])) * MAX_ANGULAR,
        )
    )
    episodes = np.repeat(np.arange(12), 40)
    return observations, actions, episodes


def test_only_expert_dataset():
    """Balanced synthetic toy scenes to test learning the actual expert function."""
    rng = np.random.default_rng(37)
    observations = rng.uniform(0.4, MAX_RANGE, size=(960, NUM_SECTORS))
    for index, sectors in enumerate(observations):
        # Keep examples away from discontinuous teacher thresholds for this
        # convergence test; near-threshold safety has its own guard tests.
        scene = index % 6
        front = (0.2, 0.5, 0.5, 0.9, 0.9, 2.0)[scene]
        sectors[[0, 11]] = front + rng.uniform(-0.03, 0.03, 2)
        left, right = (2.5, 0.7) if scene % 2 else (0.7, 2.5)
        sectors[1:4] = left + rng.uniform(-0.15, 0.15, 3)
        sectors[8:11] = right + rng.uniform(-0.15, 0.15, 3)
    actions = np.asarray([expert_action(sectors) for sectors in observations])
    return observations, actions, np.repeat(np.arange(12), 80)


class ScanTests(unittest.TestCase):
    def test_negative_start_angle_and_minimum_distance(self):
        scan = test_only_scan()
        scan.ranges[185] = 0.7  # +5 degrees, bin 0
        scan.ranges[190] = 0.4
        scan.ranges[175] = 0.8  # -5 degrees, bin 11
        sectors, valid = sectors_for(scan)
        self.assertTrue(valid)
        self.assertEqual(sectors.shape, (12,))
        self.assertEqual(sectors[0], 0.4)
        self.assertEqual(sectors[11], 0.8)

    def test_rotating_array_start_does_not_rotate_physical_front(self):
        for start in (-math.pi, 0.0, math.pi / 2, math.tau):
            with self.subTest(start=start):
                sectors, valid = sectors_for(test_only_scan(start, front_distance=0.1))
                self.assertTrue(valid)
                self.assertLessEqual(min(sectors[0], sectors[11]), 0.1)
                self.assertEqual(safe_action(sectors, (MAX_LINEAR, 0), 0), (0.0, 0.0))

    def test_negative_increment_preserves_zero_front(self):
        scan = test_only_scan()
        scan.ranges = scan.ranges[::-1]
        scan.angle_min += 359 * scan.angle_increment
        scan.angle_increment *= -1
        sectors, valid = sectors_for(scan)
        self.assertTrue(valid)
        np.testing.assert_allclose(sectors, 2.0)

    def test_half_bin_centres_match_contract_order(self):
        ranges = np.linspace(0.5, 1.6, 12)
        sectors, valid = scan_to_sectors(ranges, math.pi / 12, math.pi / 6, 0.05, 3.5)
        self.assertTrue(valid)
        np.testing.assert_allclose(sectors, ranges)

    def test_positive_infinity_means_clear_with_some_finite_evidence(self):
        scan = test_only_scan()
        scan.ranges[:] = np.inf
        scan.ranges[185] = 1.25
        sectors, valid = sectors_for(scan)
        self.assertTrue(valid)
        self.assertEqual(sectors[0], 1.25)
        self.assertEqual(sectors[5], MAX_RANGE)

    def test_infinity_never_exceeds_sensor_maximum(self):
        scan = test_only_scan()
        scan.range_max = 1.0
        scan.ranges[:] = np.inf
        scan.ranges[185] = 0.75
        sectors, valid = sectors_for(scan)
        self.assertTrue(valid)
        self.assertLessEqual(float(sectors.max()), 1.0)

    def test_all_infinity_is_invalid(self):
        scan = test_only_scan()
        scan.ranges[:] = np.inf
        sectors, valid = sectors_for(scan)
        self.assertFalse(valid)
        self.assertEqual(safe_action(sectors, (0.1, 0), 0, valid), (0.0, 0.0))

    def test_invalid_sample_cannot_hide_behind_good_ray_in_same_bin(self):
        for bad in (np.nan, -np.inf, -1.0, 0.01, 4.0):
            with self.subTest(bad=bad):
                scan = test_only_scan()
                scan.ranges[185] = bad
                sectors, valid = sectors_for(scan)
                self.assertFalse(valid)
                self.assertEqual(sectors[0], 0.0)

    def test_missing_bins_are_zero_and_invalid(self):
        sectors, valid = scan_to_sectors(np.ones(180), 0, math.pi / 180, 0.05, 3.5)
        self.assertFalse(valid)
        np.testing.assert_array_equal(sectors[6:], 0)

    def test_empty_fully_invalid_and_bad_specs(self):
        for values in ([], [np.nan] * 360, [-np.inf] * 360, [[1]] * 12):
            with self.subTest(values=str(values)[:40]):
                sectors, valid = scan_to_sectors(values, -math.pi, math.pi / 180, 0.05, 3.5)
                self.assertFalse(valid)
                self.assertTrue(np.isfinite(sectors).all())
        for field, value in (
            ("angle_increment", 0),
            ("angle_increment", np.nan),
            ("angle_increment", 0.5),
            ("angle_min", np.inf),
            ("range_min", -1),
            ("range_max", 0.01),
            ("range_max", np.inf),
        ):
            scan = test_only_scan()
            setattr(scan, field, value)
            with self.subTest(field=field, value=value):
                self.assertFalse(sectors_for(scan)[1])

    def test_finite_distances_are_capped_to_model_range(self):
        sectors, valid = scan_to_sectors(np.full(360, 7.0), 0, math.pi / 180, 0.05, 8.0)
        self.assertTrue(valid)
        np.testing.assert_array_equal(sectors, MAX_RANGE)


class GuardTests(unittest.TestCase):
    def setUp(self):
        self.clear = np.full(NUM_SECTORS, MAX_RANGE)

    def test_speed_clipping_and_no_reverse(self):
        self.assertEqual(safe_action(self.clear, (100, -100), 0), (MAX_LINEAR, -MAX_ANGULAR))
        self.assertEqual(safe_action(self.clear, (-1, 100), 0), (0, MAX_ANGULAR))
        self.assertEqual(safe_action(self.clear, (0.08, 0.2), 0), (0.08, 0.2))

    def test_bad_values_and_scan_age_fail_closed(self):
        for requested in ((np.nan, 0), (0, np.inf), [1], [[1, 2]], None):
            self.assertEqual(safe_action(self.clear, requested, 0), (0, 0))
        for age in (-0.1, np.nan, np.inf, SCAN_TIMEOUT, SCAN_TIMEOUT + 1, "bad"):
            self.assertEqual(safe_action(self.clear, (0.1, 0.2), age), (0, 0))
        for sectors in (np.zeros(11), [np.nan] * 12, [-1] * 12, None):
            self.assertEqual(safe_action(sectors, (0.1, 0.2), 0), (0, 0))
        self.assertEqual(safe_action(self.clear, (0.1, 0.2), 0, valid=False), (0, 0))

    def test_both_front_bins_stop_at_boundary(self):
        for index in (0, 11):
            sectors = self.clear.copy()
            sectors[index] = STOP_DISTANCE
            self.assertEqual(safe_action(sectors, (0.1, 0.2), 0), (0, 0))
        sectors = self.clear.copy()
        sectors[6] = 0.1  # Rear is not the front stop sector.
        self.assertEqual(safe_action(sectors, (0.1, 0.2), 0), (0.1, 0.2))

    def test_fault_latches_after_valid_scan_returns(self):
        for kind in ("timeout", "invalid", "obstacle", "prediction"):
            guard = SafetyGuard()
            if kind == "timeout":
                guard.check_timeout(SCAN_TIMEOUT)
            elif kind == "invalid":
                guard.apply(self.clear, (0.1, 0), 0, valid=False)
            elif kind == "obstacle":
                guard.apply(np.zeros(12), (0.1, 0), 0)
            else:
                guard.apply(self.clear, (np.nan, 0), 0)
            with self.subTest(kind=kind):
                self.assertIsNotNone(guard.fault_reason)
                self.assertEqual(guard.apply(self.clear, (0.1, 0), 0), (0, 0))
                self.assertFalse(guard.check_timeout(0))
                self.assertEqual(SafetyGuard().apply(self.clear, (0.1, 0), 0), (0.1, 0))

    def test_expert_uses_front_and_turns_toward_open_side(self):
        self.assertEqual(expert_action(self.clear), (MAX_LINEAR, 0))
        sectors = self.clear.copy()
        sectors[[0, 11]] = 0.5
        sectors[1:4] = 0.4
        self.assertEqual(expert_action(sectors), (0, -MAX_ANGULAR))
        sectors[0] = 0.1
        self.assertEqual(expert_action(sectors), (0, 0))


class ArtifactTests(unittest.TestCase):
    def test_roundtrip_and_shared_metre_normalization(self):
        policy = test_only_policy()
        sectors = np.linspace(0.0, MAX_RANGE, NUM_SECTORS)
        np.testing.assert_allclose(normalize_observations(sectors), sectors / MAX_RANGE)
        np.testing.assert_array_equal(normalize_observations(np.full(12, 99)), 1)
        with tempfile.TemporaryDirectory(prefix="policy-test-only-") as directory:
            path = Path(directory) / "policy.npz"
            policy.save(path)
            restored = Policy.load(path)
            np.testing.assert_array_equal(restored.predict(sectors), policy.predict(sectors))
            np.testing.assert_array_equal(
                restored.predict(np.full(12, 99)), restored.predict(np.full(12, MAX_RANGE))
            )
            with np.load(path, allow_pickle=False) as artifact:
                self.assertEqual(artifact["metadata"].dtype.kind, "U")
                self.assertEqual(json.loads(artifact["metadata"].item())["version"], 1)

    def test_tampered_version_units_shape_and_nonfinite_weights_rejected(self):
        with tempfile.TemporaryDirectory(prefix="policy-test-only-") as directory:
            path = Path(directory) / "policy.npz"
            test_only_policy().save(path)
            with np.load(path, allow_pickle=False) as data:
                original = {key: data[key].copy() for key in data.files}
            for field, value in (("version", 99), ("max_linear", 1.2), ("hidden", 129)):
                changed = dict(original)
                metadata = json.loads(changed["metadata"].item())
                metadata[field] = value
                changed["metadata"] = np.asarray(json.dumps(metadata))
                np.savez(path, **changed)
                with self.subTest(field=field), self.assertRaises(ValueError):
                    Policy.load(path)
            for replacement in (np.zeros((12, 7)), np.full((12, 8), np.nan)):
                changed = dict(original, w1=replacement)
                np.savez(path, **changed)
                with self.assertRaises(ValueError):
                    Policy.load(path)

    def test_object_arrays_unknown_keys_and_non_zip_rejected(self):
        with tempfile.TemporaryDirectory(prefix="policy-test-only-") as directory:
            path = Path(directory) / "policy.npz"
            test_only_policy().save(path)
            with np.load(path, allow_pickle=False) as data:
                original = {key: data[key].copy() for key in data.files}
            for key in ("metadata", "w1"):
                np.savez(path, **dict(original, **{key: np.asarray({"unsafe": True}, dtype=object)}))
                with self.subTest(key=key), self.assertRaises(ValueError):
                    Policy.load(path)
            np.savez(path, **original, unexpected=np.zeros(1))
            with self.assertRaises(ValueError):
                Policy.load(path)
            path.write_text("not an artifact", encoding="utf-8")
            with self.assertRaises(ValueError):
                Policy.load(path)

    def test_prediction_rejects_invalid_inputs(self):
        policy = test_only_policy()
        for sectors in (np.zeros(11), np.full(12, np.nan), np.full(12, -1)):
            with self.assertRaises(ValueError):
                policy.predict(sectors)
        predictions = policy.predict_batch(np.full((20, 12), MAX_RANGE))
        self.assertTrue(np.isfinite(predictions).all())
        self.assertTrue((predictions[:, 0] >= 0).all())
        self.assertTrue((predictions[:, 0] <= MAX_LINEAR).all())
        self.assertTrue((np.abs(predictions[:, 1]) <= MAX_ANGULAR).all())


class TrainingTests(unittest.TestCase):
    def test_split_is_deterministic_and_episode_held_out(self):
        episodes = np.tile(np.arange(12), 20)  # Interleaved episodes prevent row-split cheating.
        train, validation = episode_split(episodes, 91)
        again = episode_split(episodes, 91)
        np.testing.assert_array_equal(train, again[0])
        np.testing.assert_array_equal(validation, again[1])
        self.assertFalse(set(episodes[train]) & set(episodes[validation]))
        self.assertEqual(set(train) | set(validation), set(range(len(episodes))))
        order = np.random.default_rng(1).permutation(len(episodes))
        _, reordered = episode_split(episodes[order], 91)
        self.assertEqual(set(episodes[validation]), set(episodes[order][reordered]))
        with self.assertRaises(ValueError):
            episode_split(np.zeros(30, dtype=int))

    def test_training_learns_and_repeats_deterministically_cpu_only(self):
        data = test_only_dataset()
        options = dict(seed=8, epochs=90, hidden=16, batch_size=64)
        policy, metrics = train_policy(*data, **options)
        repeat, repeat_metrics = train_policy(*data, **options)
        final = metrics["validation"]["normalized_mse"]
        self.assertLess(final, 0.02)
        self.assertLess(final, metrics["initial_validation"]["normalized_mse"] * 0.2)
        self.assertLess(final, metrics["constant_baseline_validation"]["normalized_mse"] * 0.2)
        np.testing.assert_array_equal(policy.predict(data[0][0]), repeat.predict(data[0][0]))
        self.assertEqual(metrics, repeat_metrics)
        self.assertFalse(set(metrics["train_episode_ids"]) & set(metrics["validation_episode_ids"]))

    def test_train_cli_writes_portable_model_and_metrics(self):
        with tempfile.TemporaryDirectory(prefix="synthetic-unit-test-only-") as directory:
            source = Path(directory) / "synthetic-test-only.npz"
            output = Path(directory) / "policy.npz"
            observations, actions, episodes = test_only_dataset()
            np.savez(source, observations=observations, actions=actions, episodes=episodes)
            result = subprocess.run(
                [sys.executable, str(CODE / "train.py"), "--data", str(source),
                 "--output", str(output), "--epochs", "30"],
                capture_output=True,
                text=True,
                timeout=60,
                env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            metrics = json.loads(output.with_name("metrics.json").read_text())
            self.assertEqual(metrics["num_samples"], len(episodes))
            self.assertTrue(np.isfinite(Policy.load(output).predict(observations[0])).all())
            self.assertLess(metrics["validation"]["normalized_mse"], 0.03)

    def test_training_converges_on_synthetic_expert_actions(self):
        data = test_only_expert_dataset()
        policy, metrics = train_policy(*data, seed=42, epochs=200, hidden=24)
        final = metrics["validation"]["normalized_mse"]
        self.assertLess(final, 0.025)
        self.assertLess(final, metrics["constant_baseline_validation"]["normalized_mse"] * 0.15)
        self.assertLess(final, metrics["initial_validation"]["normalized_mse"] * 0.15)
        _, validation = episode_split(data[2], seed=42)
        turn_rows = validation[np.abs(data[1][validation, 1]) > 0.2]
        predicted = policy.predict_batch(data[0][turn_rows])
        self.assertGreater(np.mean(np.sign(predicted[:, 1]) == np.sign(data[1][turn_rows, 1])), 0.95)

    def test_dataset_validation_rejects_wrong_units_and_episode_type(self):
        observations, actions, episodes = test_only_dataset()
        with tempfile.TemporaryDirectory(prefix="policy-test-only-") as directory:
            path = Path(directory) / "dataset.npz"
            for bad_actions, bad_episodes in (
                (actions * 100, episodes),
                (actions, episodes.astype(float)),
                (actions, np.zeros_like(episodes)),
                (np.full_like(actions, np.nan), episodes),
            ):
                np.savez(path, observations=observations, actions=bad_actions, episodes=bad_episodes)
                with self.assertRaises(ValueError):
                    load_dataset(path)


class EdgeControllerTests(unittest.TestCase):
    def setUp(self):
        self.now = 0.0
        self.sent = []
        self.publishers = 1
        self.types = [COMMAND_TYPE]
        self.policy = SimpleNamespace(predict=lambda _: (0.1, 0.2))
        self.controller = EdgeController(
            self.policy,
            self.sent.append,
            lambda: self.publishers,
            lambda: self.types,
            clock=lambda: self.now,
        )

    def start_valid_scans(self):
        start = self.now
        for index in range(12):
            self.now = start + index / 10
            self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (DEFAULT_MAX_LINEAR, 0.2))

    def test_default_cli_is_preview_and_arm_is_explicit(self):
        args = build_parser().parse_args(["--model", "policy.npz"])
        self.assertFalse(args.arm)
        self.assertEqual(args.cmd_topic, "/cmd_vel")
        self.assertEqual(args.scan_topic, "/scan")
        self.assertEqual(args.max_linear, 0.05)
        self.assertTrue(build_parser().parse_args(["--model", "p.npz", "--arm"]).arm)
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            build_parser().parse_args(["--model", "p.npz", "--cmd-topic", "/other"])

    def test_watchdog_with_no_scan_publishes_zero_and_latches(self):
        self.assertEqual(self.sent, [(0.0, 0.0)])
        self.now = SCAN_TIMEOUT
        self.controller.watchdog()
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.assertEqual(self.controller.guard.fault_reason, "scan timeout")
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (0.0, 0.0))

    def test_watchdog_stops_motion_without_any_new_scan(self):
        self.start_valid_scans()
        self.now += SCAN_TIMEOUT
        self.controller.watchdog()
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (0.0, 0.0))

    def test_delayed_scan_cannot_bypass_watchdog(self):
        self.start_valid_scans()
        self.now += SCAN_TIMEOUT + 0.01
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.assertEqual(self.controller.guard.fault_reason, "scan timeout")

    def test_obstacle_and_invalid_scan_latch(self):
        self.start_valid_scans()
        self.controller.on_scan(test_only_scan(front_distance=0.1))
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-2:], [(0.0, 0.0), (0.0, 0.0)])
        self.assertIn("front obstacle", self.controller.guard.fault_reason)

    def test_prediction_exception_and_nan_stop(self):
        for prediction in (lambda _: (_ for _ in ()).throw(RuntimeError("test")),
                           lambda _: (np.nan, 0)):
            self.setUp()
            self.start_valid_scans()
            self.policy.predict = prediction
            self.controller.on_scan(test_only_scan())
            self.assertIsNotNone(self.controller.guard.fault_reason)
            self.assertEqual(self.sent[-1], (0.0, 0.0))

    def test_conflicting_publisher_latches_stop(self):
        self.start_valid_scans()
        self.publishers = 2
        self.controller.watchdog()
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.publishers = 1
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (0.0, 0.0))

    def test_mismatched_subscriber_or_publisher_type_latches_stop(self):
        self.start_valid_scans()
        self.types.append("geometry_msgs/msg/TwistStamped")
        self.controller.watchdog()
        self.assertIn("type mismatch", self.controller.guard.fault_reason)
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.types = [COMMAND_TYPE]
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (0.0, 0.0))

    def test_no_motion_during_discovery_grace(self):
        self.publishers = 0
        self.types = []
        self.now = 0.1
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.assertIsNone(self.controller.guard.fault_reason)
        self.publishers = 1
        self.types = [COMMAND_TYPE]
        self.start_valid_scans()

    def test_missing_graph_after_grace_fails_closed(self):
        self.start_valid_scans()
        self.types = []
        self.controller.watchdog()
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.assertIn("unavailable", self.controller.guard.fault_reason)

    def test_invalid_scan_latches_without_invoking_policy(self):
        self.start_valid_scans()
        self.policy.predict = lambda _: self.fail("Invalid scan must not reach inference")
        scan = test_only_scan()
        scan.ranges[185] = np.nan
        self.controller.on_scan(scan)
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.assertEqual(self.controller.guard.fault_reason, "invalid scan")

    def test_device_cap_cannot_exceed_model_limit(self):
        for cap in (-0.1, 0, 0.121, np.nan, np.inf):
            with self.subTest(cap=cap), self.assertRaises(ValueError):
                EdgeController(
                    self.policy, self.sent.append, lambda: 1, lambda: [COMMAND_TYPE],
                    max_linear=cap, clock=lambda: self.now,
                )

    def test_shutdown_publishes_zero_and_prevents_recovery(self):
        self.start_valid_scans()
        self.controller.stop()
        self.assertEqual(self.sent[-1], (0.0, 0.0))
        self.controller.on_scan(test_only_scan())
        self.assertEqual(self.sent[-1], (0.0, 0.0))


if __name__ == "__main__":
    unittest.main()
