"""Offline installer and C++ timing tests; no ROS, firmware, or physical execution."""

from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

DEVICE = Path(__file__).resolve().parents[1] / "static" / "code" / "device"
sys.path.insert(0, str(DEVICE))
import apply_bringup_watchdog as patcher

# Minimal synthetic source fixtures exercise exact edit anchors. Only tests
# override the original hashes; production always requires the pinned full files.
SOURCE_FIXTURE = b"""void heartbeat()
{
      static uint8_t count = 0;
      write_heartbeat(count);
      count++;
}
void commands()
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(10));
      [this](const geometry_msgs::msg::Twist::SharedPtr msg) -> void
      {
        write_twist(msg);
      }
      [this](const geometry_msgs::msg::TwistStamped::SharedPtr msg) -> void
      {
        write_stamped(msg);
      }
}
"""
HEADER_FIXTURE = b"""#include "turtlebot3_node/twist_subscriber.hpp"
class TurtleBot3 {
  std::unique_ptr<TwistSubscriber> cmd_vel_sub_;
};
"""


class PatcherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="bringup-patcher-test-only-")
        self.addCleanup(self.temp.cleanup)
        self.workspace = Path(self.temp.name)
        self.package = self.workspace / patcher.PACKAGE_PATH
        self.originals = {
            patcher.SOURCE_PATH: SOURCE_FIXTURE,
            patcher.HEADER_PATH: HEADER_FIXTURE,
        }
        for relative, content in self.originals.items():
            path = self.package / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        self.fake_hashes = {key: patcher.sha256(value) for key, value in self.originals.items()}

    def fixture_hashes(self):
        return mock.patch.dict(patcher.ORIGINAL_HASHES, self.fake_hashes, clear=True)

    def snapshot(self):
        return {
            str(path.relative_to(self.workspace)): path.read_bytes()
            for path in self.workspace.rglob("*") if path.is_file()
        }

    def test_default_pinned_hashes_reject_synthetic_files_without_writes(self):
        before = self.snapshot()
        with self.assertRaises(patcher.PatchError):
            patcher.apply_watchdog(self.workspace)
        self.assertEqual(self.snapshot(), before)

    def test_patch_both_callbacks_gate_before_counter_and_keep_depth_one(self):
        transformed = patcher.patch_source(SOURCE_FIXTURE).decode()
        self.assertEqual(transformed.count("command_watchdog_.command_received();"), 2)
        self.assertLess(transformed.index("allow_heartbeat"), transformed.index("static uint8_t"))
        self.assertLess(transformed.index("allow_heartbeat"), transformed.index("write_heartbeat"))
        self.assertIn("KeepLast(1)", transformed)
        self.assertNotIn("KeepLast(10)", transformed)
        with self.assertRaises(patcher.PatchError):
            patcher.patch_source(SOURCE_FIXTURE.replace(b"static uint8_t count = 0;", b"changed"))

    def test_install_backups_idempotence_modes_and_unrelated_file_preserved(self):
        unrelated = self.package / "user-notes.txt"
        unrelated.write_text("Do not change", encoding="utf-8")
        target = self.package / patcher.SOURCE_PATH
        target.chmod(0o640)
        with self.fixture_hashes():
            plan = patcher.apply_watchdog(self.workspace)
            self.assertTrue(plan.already_applied)
            first = self.snapshot()
            timestamps = {p: p.stat().st_mtime_ns for p in self.workspace.rglob("*") if p.is_file()}
            self.assertTrue(patcher.apply_watchdog(self.workspace).already_applied)
            self.assertEqual(self.snapshot(), first)
            self.assertEqual(timestamps, {p: p.stat().st_mtime_ns for p in timestamps})
        for item in plan.files:
            self.assertEqual(item.backup.read_bytes(), item.original)
            self.assertEqual(item.path.read_bytes(), item.patched)
        self.assertEqual(target.stat().st_mode & 0o777, 0o640)
        self.assertEqual(unrelated.read_text(), "Do not change")

    def test_check_only_has_no_side_effect(self):
        before = self.snapshot()
        with self.fixture_hashes():
            plan = patcher.apply_watchdog(self.workspace, check_only=True)
        self.assertFalse(plan.already_applied)
        self.assertEqual(before, self.snapshot())

    def test_modified_second_input_refuses_all_changes(self):
        path = self.package / patcher.HEADER_PATH
        path.write_bytes(HEADER_FIXTURE + b"// unrelated user edit\n")
        before = self.snapshot()
        with self.fixture_hashes(), self.assertRaises(patcher.PatchError):
            patcher.apply_watchdog(self.workspace)
        self.assertEqual(before, self.snapshot())

    def test_conflicting_backup_or_helper_refuses_all_changes(self):
        for relative in (
            Path(str(patcher.SOURCE_PATH) + patcher.BACKUP_SUFFIX), patcher.HELPER_PATH
        ):
            path = self.package / relative
            path.write_bytes(b"unrelated existing file")
            before = self.snapshot()
            with self.fixture_hashes(), self.assertRaises(patcher.PatchError):
                patcher.apply_watchdog(self.workspace)
            self.assertEqual(before, self.snapshot())
            path.unlink()  # Only this test-owned fixture.

    def test_tampered_patched_file_is_not_accepted_by_marker(self):
        with self.fixture_hashes():
            patcher.apply_watchdog(self.workspace)
            target = self.package / patcher.SOURCE_PATH
            target.write_bytes(target.read_bytes() + b"// later user edit\n")
            before = self.snapshot()
            with self.assertRaises(patcher.PatchError):
                patcher.apply_watchdog(self.workspace)
            self.assertEqual(before, self.snapshot())

    def test_resume_after_interrupted_install_uses_authenticated_backups(self):
        with self.fixture_hashes():
            original_replace = patcher._replace_verified
            calls = []

            def fail_on_second(item):
                calls.append(item.path)
                if len(calls) == 2:
                    raise OSError("test-only interrupted install")
                original_replace(item)

            with mock.patch.object(patcher, "_replace_verified", side_effect=fail_on_second):
                with self.assertRaises(OSError):
                    patcher.apply_watchdog(self.workspace)
            plan = patcher.apply_watchdog(self.workspace)
            self.assertTrue(plan.already_applied)
            for item in plan.files:
                self.assertEqual(item.backup.read_bytes(), item.original)

    def test_symlink_target_refused(self):
        target = self.package / patcher.SOURCE_PATH
        outside = self.workspace / "do-not-edit.cpp"
        outside.write_bytes(SOURCE_FIXTURE)
        target.unlink()
        target.symlink_to(outside)
        before = outside.read_bytes()
        with self.fixture_hashes(), self.assertRaises(patcher.PatchError):
            patcher.apply_watchdog(self.workspace)
        self.assertEqual(outside.read_bytes(), before)
        self.assertFalse((self.package / patcher.HELPER_PATH).exists())

    def test_source_changed_between_preflight_and_replace_is_preserved(self):
        with self.fixture_hashes():
            plan = patcher.inspect_workspace(self.workspace)
            item = plan.files[0]
            item.path.write_bytes(b"user edit made after validation")
            with self.assertRaises(patcher.PatchError):
                patcher._replace_verified(item)
            self.assertEqual(item.path.read_bytes(), b"user edit made after validation")


class CppTimingTests(unittest.TestCase):
    def test_actual_bundled_header_cold_start_timeout_refresh_and_modelled_heartbeat(self):
        compiler = shutil.which("c++")
        if compiler is None:
            self.skipTest("C++ compiler unavailable; header timing test not run")
        code = r'''
#include "workshop_cmd_vel_watchdog.hpp"
#include <cassert>
#include <chrono>
#include <iostream>
#include <thread>

int main()
{
  using Watchdog = workshop::CommandHeartbeatWatchdog;
  using namespace std::chrono;
  const Watchdog::TimePoint base{};
  Watchdog guard;
  assert(!guard.allow_heartbeat(base));
  assert(!guard.allow_heartbeat(base + hours(1)));
  guard.command_received(base);
  assert(guard.allow_heartbeat(base));
  assert(guard.allow_heartbeat(base + milliseconds(499)));
  assert(!guard.allow_heartbeat(base + milliseconds(500)));
  assert(!guard.allow_heartbeat(base + milliseconds(501)));
  assert(!guard.allow_heartbeat(base - milliseconds(1)));
  guard.command_received(base + seconds(2));
  assert(guard.allow_heartbeat(base + milliseconds(2499)));
  assert(!guard.allow_heartbeat(base + milliseconds(2500)));

  // Synthetic schedule, not measured firmware/motor timing. A healthy producer
  // issues commands every 200 ms; it stops at 1000 ms. Bringup ticks every 100 ms.
  Watchdog schedule;
  int heartbeat_count = 0;
  int last_sent = -1;
  int simulated_disconnect = -1;
  for (int ms = 0; ms <= 2600; ms += 100) {
    if (ms <= 1000 && ms % 200 == 0) {
      schedule.command_received(base + milliseconds(ms));
    }
    if (schedule.allow_heartbeat(base + milliseconds(ms))) {
      ++heartbeat_count;
      last_sent = ms;
    }
    if (last_sent >= 0 && ms - last_sent > 500 && simulated_disconnect < 0) {
      simulated_disconnect = ms;
    }
  }
  assert(heartbeat_count == 15);
  assert(last_sent == 1400);
  assert(simulated_disconnect == 2000);
  assert(simulated_disconnect - 1000 <= 1500);
  schedule.command_received(base + milliseconds(3000));
  assert(schedule.allow_heartbeat(base + milliseconds(3000)));

  // The helper stays defined under concurrent callbacks as well.
  Watchdog concurrent;
  std::thread writer([&]() {
    for (int i = 0; i < 1000; ++i) {
      concurrent.command_received(base + milliseconds(i));
    }
  });
  std::thread reader([&]() {
    for (int i = 0; i < 1000; ++i) {
      (void)concurrent.allow_heartbeat(base + milliseconds(i));
    }
  });
  writer.join();
  reader.join();
  assert(concurrent.allow_heartbeat(base + milliseconds(1000)));
  std::cout << "offline clock/heartbeat checks passed\n";
}
'''
        with tempfile.TemporaryDirectory(prefix="watchdog-cpp-test-only-") as directory:
            source = Path(directory) / "watchdog_test.cpp"
            binary = Path(directory) / "watchdog_test"
            source.write_text(code, encoding="utf-8")
            platform_flags = []
            if sys.platform == "darwin":
                # Some Command Line Tools releases install libc++ headers only
                # inside the SDK, outside clang's default header search path.
                sdk = subprocess.run(
                    ["xcrun", "--show-sdk-path"], capture_output=True, text=True, timeout=10
                )
                self.assertEqual(sdk.returncode, 0, sdk.stderr)
                headers = Path(sdk.stdout.strip()) / "usr/include/c++/v1"
                if headers.is_dir():
                    platform_flags = ["-isysroot", sdk.stdout.strip(), "-isystem", str(headers)]
            build = subprocess.run(
                [compiler, "-std=c++14", "-Wall", "-Wextra", "-Werror", "-pthread",
                 *platform_flags, "-I", str(DEVICE), str(source), "-o", str(binary)],
                capture_output=True, text=True, timeout=60,
            )
            self.assertEqual(build.returncode, 0, build.stderr)
            run = subprocess.run([str(binary)], capture_output=True, text=True, timeout=10)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertIn("checks passed", run.stdout)


if __name__ == "__main__":
    unittest.main()
