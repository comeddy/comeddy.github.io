# 처음 만드는 Physical AI: Isaac Sim on AWS → 실제 이동로봇

**한국어 · 사전 준비 + 하루 7시간 · TurtleBot3 Burger · 초급**

AWS의 NVIDIA Isaac Sim에서 주행 데이터를 만들고, 작은 신경망을 학습한 뒤
Raspberry Pi에 옮겨 실제 로봇이 장애물을 피하도록 만드는 워크샵입니다.
실습의 학습 방식은 **규칙 기반 교사를 따라 배우는 모방학습**입니다.

공개 교재는 [GitHub Pages](https://comeddy.github.io/pai/issacsim/)에서 읽고,
[실습 코드 ZIP](https://comeddy.github.io/pai/issacsim/downloads/physical-ai-isaac-aws.zip)을 받을 수 있습니다.
배포된 파일은 [사이트 저장소](https://github.com/comeddy/comeddy.github.io/tree/master/pai/issacsim)에서 확인합니다.

오프라인에서는 [index.html](index.html)을 브라우저에서 여세요.
마크다운으로는 [여기](content/index.ko.md)에서 시작합니다.
AWS 구성도·설명 그림 6개와 실제 Isaac Sim 실행 화면 1개가 교재에 포함되어 있습니다.
HTML에는 이미지를 내장했으며 그림을 누르면 확대할 수 있습니다.
모듈 3에는 [회전·확대할 수 있는 3D 실습장](static/visuals/arena-3d.html)도 들어 있습니다.
3D 뷰어는 인터넷 없이 열리며, 실습 코드의 배치를 설명하는 단순화한 모델입니다.

## 시작 전에 알아둘 것

- 기본 장비는 **TurtleBot3 Burger + Raspberry Pi 4 + LDS + OpenCR**입니다.
  Jetson만으로는 바퀴가 움직이지 않습니다. 다른 로봇은 센서·구동부 변환이 필요합니다.
- AWS 개인/회사 실습 계정과 **G 계열 On-Demand vCPU 한도 16 이상**을 미리 준비합니다.
  기본 인스턴스는 `g6.4xlarge`입니다. 재고 부족 시 `INSTANCE_TYPE=g6e.2xlarge`를
  명시적으로 선택할 수 있습니다. G6e는 8 vCPU 여유가 필요하며 단가가 다릅니다.
- 문서 버전 기준은 **Isaac Sim 5.1.0, Ubuntu 22.04, ROS 2 Humble**입니다.
  버전을 섞어서 설치하지 마세요.
- AWS GPU 배포·Isaac Sim 실행과 Linux ARM의 ROS 2 코드 검사를 실제로 수행했습니다.
  실물 로봇 시험은 연결된 장비에서 별도로 진행해야 합니다. [검증 기록](docs/verification.md)을 보세요.
  이번 학습 모델은 측면 근접·낮은 이동 구간이 확인돼 **실물 바닥 주행을 보류**했습니다.

## 7시간 과정

| 단계 | 시간 | 얻는 결과 |
|---|---:|---|
| 개념과 준비 확인 | 30분 | “센서 → AI → 모터” 이해 |
| AWS GPU 환경 만들기 | 50분 | Isaac Sim을 실행할 EC2 |
| 가상 로봇 실행 | 50분 | 장애물이 있는 가상 공간 |
| 데이터 수집 | 45분 | 실제 시뮬레이션에서 얻은 학습 데이터 |
| 모델 학습 | 40분 | `policy.npz` |
| 가상 검증 | 35분 | 보지 않은 환경의 평가 결과 |
| 실물 준비와 배포 | 60분 | 로봇 내부에서 모델 추론 |
| 그림자 실행과 저속 주행 | 65분 | 단계적으로 확인한 동작 |
| 정리와 회고 | 15분 | 비용 종료와 실습 기록 |

OS 이미지 굽기, 로봇 조립, GPU 한도 상향, 컨테이너 최초 다운로드는 전날 준비합니다.
당일 처음 설치한다면 2일로 나누는 편이 현실적입니다.

## 파일 안내

- `content/`: Workshop Studio용 한국어 교재.
- `static/workshop.yaml`: EC2·네트워크·S3 CloudFormation.
- `static/workshop-existing-network.json`: 기존 공개 VPC·서브넷을 사용하는 선택형 템플릿.
- `scripts/cloud/`: AWS 배포와 GPU 환경 준비.
- `static/code/sim/`: Isaac Sim 데이터 수집·평가.
- `static/code/workshop_core.py`, `train.py`: 공통 입력 처리와 모델 학습.
- `static/code/device/`: 실제 ROS 2 로봇 실행 코드.
- `static/code/device/apply_bringup_watchdog.py`: 정책 종료 시 마지막 속도가 남지 않도록 bringup 보완.
- `tests/`: 입력 처리·정지 로직·모델 검증.
- `docs/`: 장비, 출처, 운영자 리허설, 검증 범위.
- `static/images/`: AWS 아키텍처와 학습용 그림의 PNG·SVG 원본.
- `static/visuals/arena-3d.html`: 설치 없이 여는 3D 실습장 뷰어.
- [이미지 안내](docs/illustrations.md): 그림별 위치와 편집 가능한 원본.
- `gitbook/`: GitBook 게시용 목차·본문·그림·실습 코드 다운로드.
- `scripts/build_gitbook.py`: 원본 교재를 GitBook 형식으로 변환하고 내용·링크·다운로드 일치를 검사.
- `scripts/build_pages.py`: GitHub Pages 사이트와 전체 실습 코드 ZIP 생성·검증.

## 자료 검증 / HTML 다시 만들기

로컬 Python 3.10 이상과 NumPy가 있으면:

```bash
bash scripts/verify-local.sh
```

센서·모델·명령 만료 보완·시뮬레이터 보조 코드·클라우드 스크립트를 검사하고 HTML을 다시 만듭니다.
C++ 컴파일러와 cfn-lint가 없으면 해당 검사는 미실행으로 표시됩니다.
이 로컬 검사는 외부 게시나 AWS 리소스 생성을 수행하지 않습니다.

## GitHub Pages 게시

공개 주소는 `https://comeddy.github.io/pai/issacsim/`입니다.
`comeddy/comeddy.github.io` 저장소의 `master` 브랜치에 있는 `pai/issacsim/`에
사이트 파일을 배치합니다. 배포 파일을 로컬에서 만들려면:

```bash
python3 scripts/build_pages.py
```

사이트 파일은 `_site/`, 실습 코드 ZIP은 저장소의 상위 폴더에 생성됩니다.
검증된 `_site/`의 내용을 사이트 저장소의 `pai/issacsim/`에 복사하고
`master`에 푸시하면 기존 GitHub Pages 빌드가 게시합니다.
사이트 저장소 루트의 Jekyll 설정과 다른 경로는 유지합니다.
게시 후 교재, `static/visuals/arena-3d.html`, `downloads/physical-ai-isaac-aws.zip`을 확인합니다.

이 워크샵에 포함된 `.github/workflows/pages.yml`은 독립 저장소의 Pages에
직접 게시할 때 사용하는 설정이며, 위 개인 사이트로 파일을 전송하지 않습니다.
GitBook 게시용 원고는 별도 경로이며 GitHub Pages 배포와 독립적입니다.
